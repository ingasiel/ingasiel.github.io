

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    
    <style>
    .contenedor_recaptcha{
    background: #0044ff50;
    width: 40%;
    height: 20%;
    position: absolute;
    top:0%;
    left:0%;
    display:flex;
    flex-wrap:wrap;
    justify-content:center;
    align-content:center;
}
    </style>
</head>
<body>

<script>
        alert("Hello world!");
</script>

    <form action="?" method="POST">
      <div class="g-recaptcha" data-sitekey="6LcRiegnAAAAAE8GtxauB-y8V8g7DBzdwaFzRmie"></div>
      <br/>
      <input type="submit" value="Submit">
    </form>

</body>
</html>

<?php

?>