<html lang='en'>

    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Registrar</title>
        <link rel='stylesheet' href='Css/iniciarregistrar3.css'>
        <link rel="icon" href="Recursos/Img/logo.png" type="img/png">

        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    </head>

    <body style='overflow-y:hidden;'>

    </body>

</html>

<?php

session_start();

if(isset($_SESSION['nombredeusuario'])){
    header('location: sistema.php');

}

?>

<div class="contenedor">
    <div class="contenedor_tarjeta_iniciar">
        <div class="contenedor_tarjeta_iniciar_seccion_izquierda">
            <img class="imagen_iniciar" src="Recursos/Img/inventario_inicio.png">
        </div>
        <div class="contenedor_tarjeta_iniciar_seccion_derecha">
            <div class="contenedor_tarjeta_iniciar_seccion_derecha_titulo">
                <p class="texto_contenedor_tarjeta_iniciar_seccion_derecha_titulo">Registrar</p>
            </div>
            <div class="contenedor_tarjeta_iniciar_seccion_derecha_formulario ajustre_registro_formulario">
                <form method="POST" class="formulario_iniciar_2" enctype='multipart/form-data'>
                    <input class="input_registrar_NombreDeEmpresa ajustre_registro_input" name="campo_nombredelaempresa_2" type="text" placeholder="Confirmar nombre de la empresa" required>
                    <input class="input_registrar_NombreDeEmpresa ajustre_registro_input_2" name="campo_contrasena1" type="password" placeholder="Contraseña" required>
                    <input class="input_registrar_NombreDeEmpresa ajustre_registro_input_2" name="campo_contrasena2" type="password" placeholder="Confirmar contraseña" required>

                    <input name='imageninformacion' type='file' />

                    <input class="input_BotonDeUsuario ajustre_registro_input" name="campo_registrar_datos_2" type="submit" value="Registrar">
                </form>
            </div>
            <div class="contenedor_tarjeta_iniciar_seccion_derecha_otrasopciones ajustre_registro_OtrasOpciones">
                <p class="texto_opciones_secundarias">Necesito ayuda</p>
            </div>
        </div>
    </div>
</div>

<?php


if(isset($_POST["campo_registrar_datos_2"])){

    include("conexion.php");

    $varnombreempresa = $_POST["campo_nombredelaempresa_2"];
    $varcontrasena1 = $_POST["campo_contrasena1"];
    $varcontrasena2 = $_POST["campo_contrasena2"];
    $varimagen = addslashes(file_get_contents($_FILES['imageninformacion']['tmp_name']));   


    if($varcontrasena1 == $varcontrasena2){


        $varcontrasena1_fuerte = password_hash($varcontrasena1, PASSWORD_DEFAULT);
        #$varnombreempresa_fuerte = password_hash($varnombreempresa, PASSWORD_DEFAULT);

        $sqlgrabar = "INSERT INTO $varnombreempresa(nombre_de_la_empresa,contrasena_de_la_empresa,cargo_de_la_persona) values ('$varnombreempresa','$varcontrasena1_fuerte','maestro')";
        $sqlgrabar2 = "UPDATE $varnombreempresa SET imagen_usuario = '$varimagen'";

        
        if(mysqli_query($conn,$sqlgrabar)){

            ?>

            <script type="text/javascript">
                swal("Bienvenido", "Ya formas parte del sistema :D", "success");

                identificadorIntervaloDeTiempo = setInterval(ocultar_cargador, 3000);

                function ocultar_cargador() {
                    location.href="inicio.php";
                }
            </script>

            <?php

        }if(mysqli_query($conn,$sqlgrabar2)){

            ?>

            <script type="text/javascript">
                let identificadorIntervaloDeTiempo2;

                swal("Empresa registrada", "Tu empresa ya forma parte del sistema", "success");

                identificadorIntervaloDeTiempo2 = setInterval(ocultar_cargador2, 3000);

                function ocultar_cargador2() {
                    location.href="registro2.php";
                }

            </script>
    
    
            <?php

        }else{
            ?>
    
            <script type="text/javascript">
                swal("Error 103", "Errorrrrrrrrrrrrrr", "error");
            </script>
    
            <?php
    
        }

    }else{
        ?>

        <script type="text/javascript">
            swal("Error 102", "Las contraseñas no coincide", "error");
        </script>


        <?php

    }

    
    
}

/*    $sqlgrabar2 = "INSERT INTO $varnombreempresa(nombre_de_la_empresa) values ('$varnombreempresa')";
*/
?>