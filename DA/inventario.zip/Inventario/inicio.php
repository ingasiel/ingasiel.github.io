<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventario | Iniciar</title>
    <link rel="stylesheet" href="Css/iniciarregistrar1.css">
    <link rel="icon" href="Recursos/Img/logo.png" type="img/png">

    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <style>
        div{
            display:block;
        }

        .display{
            display:flex;
            flex-wrap:wrap;
        }
    </style>

</head>
<body style="overflow-y:hidden;">

</body>
</html>

<?php

session_start();

if(isset($_SESSION['nombredeusuario'])){
    header('location: sistema.php');
}



echo'<div class="contenedor">
        <div class="contenedor_tarjeta_iniciar">
            <div class="contenedor_tarjeta_iniciar_seccion_izquierda">
                <img class="imagen_iniciar" src="Recursos/Img/inventario_inicio.png">
            </div>
            <div class="contenedor_tarjeta_iniciar_seccion_derecha">
                <div class="contenedor_tarjeta_iniciar_seccion_derecha_titulo">
                    <p class="texto_contenedor_tarjeta_iniciar_seccion_derecha_titulo">Iniciar</p>
                </div>
                <div class="contenedor_tarjeta_iniciar_seccion_derecha_formulario">
                    <form method="POST" class="formulario_iniciar">
                        <input class="input_NombreDeUsuario" type="text" name="campo_iniciar_sesion_nombre_empresa" placeholder="Nombre de usuario" required>
                        <input class="input_ContrasenaDeUsuario" type="password" name="campo_iniciar_sesion_password" placeholder="Contraseña" required>
                        <input class="input_BotonDeUsuario" type="submit" name="input_submit_IR_inicicarsesion" value="Iniciar">
                    </form>
                </div>
                <div class="contenedor_tarjeta_iniciar_seccion_derecha_otrasopciones">
                    <p class="texto_OlvideMiContrasena">¿Olvidaste tu contraseña?</p>
                    <p class="texto_opciones_secundarias">Necesito ayuda</p>
                    <a href="registro.php"><p class="texto_opciones_secundarias">soy nuevo</p>
                </div>
            </div>
        </div>
    </div>';



if(isset($_POST["input_submit_IR_inicicarsesion"])){

    include("conexion.php");

    $varusuarioadmin = $_POST["campo_iniciar_sesion_nombre_empresa"];
    $varcontrasena1= $_POST["campo_iniciar_sesion_password"];

    $sqlgrabar = mysqli_query($conn, "SELECT * FROM $varusuarioadmin WHERE nombre_de_la_empresa = '$varusuarioadmin'");
    $nr = mysqli_num_rows($sqlgrabar);
    $buscarpassword = mysqli_fetch_array($sqlgrabar);


    if(!isset($_SESSION['nombredeusuario'])){

        if(($nr==1)&&(password_verify($varcontrasena1,$buscarpassword['contrasena_de_la_empresa']))){
            $_SESSION['nombredeusuario']=$varusuarioadmin;
            header("Location: sistema.php");
        }else if($nr == 0){
            ?>

            <script type="text/javascript">
                swal("Error 101", "La contraseña no coincide", "error");
            </script>

            <?php
        }

    }

}


?>