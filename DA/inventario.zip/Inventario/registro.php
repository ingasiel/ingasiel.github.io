<html lang='en'>

    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Inventario | Registrar</title>
        <link rel='stylesheet' href='Css/iniciarregistrar3.css'>
        <link rel="icon" href="Recursos/Img/logo.png" type="img/png">
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

        <script src="https://www.google.com/recaptcha/api.js" async defer></script>

    </head>

    <body>

    </body>

</html>

<?php

session_start();

if(isset($_SESSION['nombredeusuario'])){
    header('location: sistema.php');
}

    ?>

    <div class="contenedor">
        <div class="contenedor_tarjeta_iniciar">
            <div class="contenedor_tarjeta_iniciar_seccion_izquierda">
                <img class="imagen_iniciar" src="Recursos/Img/inventario_inicio.png">
            </div>
            <div class="contenedor_tarjeta_iniciar_seccion_derecha">
                <div class="contenedor_tarjeta_iniciar_seccion_derecha_titulo">
                    <p class="texto_contenedor_tarjeta_iniciar_seccion_derecha_titulo">Registrar</p>
                </div>
                <div class="contenedor_tarjeta_iniciar_seccion_derecha_formulario ajustre_registro_formulario">
                    <form method="POST" class="formulario_iniciar">
                        <input class="input_registrar_NombreDeEmpresa ajustre_registro_input" name="campo_nombredelaempresa" type="text" placeholder="Nombre de la empresa" required>

                        <div class="g-recaptcha" data-sitekey="6LcRiegnAAAAAE8GtxauB-y8V8g7DBzdwaFzRmie"></div>

                        <input class="input_BotonDeUsuario ajustre_registro_input" name="campo_registrar_datos" type="submit" value="Registrar">
                    </form>
                </div>
                <div class="contenedor_tarjeta_iniciar_seccion_derecha_otrasopciones ajustre_registro_OtrasOpciones">
                    <p class="texto_opciones_secundarias">Necesito ayuda</p>
                    <a href="inicio.php"><p class="texto_opciones_secundarias">Ya tengo cuenta</p></a>
                </div>
            </div>
        </div>
    </div>

    <?php


if(isset($_POST["campo_registrar_datos"])){

    include("conexion.php");


    $varnombreempresa = $_POST["campo_nombredelaempresa"];
    $varverificardatos = $_POST["campo_verificar_datos"];
    $varsucursal = "_sucursal";


    $ip = $_SERVER['REMOTE_ADDR'];
    $captcha = $_POST['g-recaptcha-response'];
    $secretkey = "6LcRiegnAAAAACxeaJ0idHerIwpDDM_gigQ9DA6R";


    $response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secretkey&
    response=$captcha&remoteip=$ip");

    $atributos = json_decode($response, TRUE);

    if(!$atributos['success']){

        ?>
        <script>
            alert("verificar captcha");
        </script>
        <?php
    }

        $sqlgrabar1 = "CREATE TABLE $varnombreempresa(nombre_de_la_empresa VARCHAR(255), contrasena_de_la_empresa VARCHAR(255), imagen_usuario LONGBLOB, cargo_de_la_persona VARCHAR(255), db_campo_cargo_empresa VARCHAR(255), db_campo_jefe_empresa VARCHAR(255), db_campo_sucursal_empresa VARCHAR(255), db_campo_sueldo_empresa VARCHAR(255), db_campo_dias_empresa VARCHAR(255), db_campo_horario_empresa VARCHAR(255), db_nombre_empleado VARCHAR(255), db_contrasena_empreado VARCHAR(255), imagen_empresa LONGBLOB)";
        $sqlgrabar2 = "CREATE TABLE $varnombreempresa".$varsucursal."(db_nombre_sucursal VARCHAR(255), db_ubicacion_sucursal VARCHAR(255))";
    

        if(mysqli_query($conn,$sqlgrabar1)){

            ?>

            <script type="text/javascript">
                let identificadorIntervaloDeTiempo;

                swal("Empresa registrada", "Tu empresa ya forma parte del sistema", "success");

                identificadorIntervaloDeTiempo = setInterval(ocultar_cargador, 3000);

                function ocultar_cargador() {
                    location.href="registro2.php";
                }

            </script>
    
    
            <?php

        }if(mysqli_query($conn,$sqlgrabar2)){

            ?>

            <script type="text/javascript">
                let identificadorIntervaloDeTiempo2;

                swal("Empresa registrada", "Tu empresa ya forma parte del sistema", "success");

                identificadorIntervaloDeTiempo2 = setInterval(ocultar_cargador2, 3000);

                function ocultar_cargador2() {
                    location.href="registro2.php";
                }

            </script>
    
    
            <?php

        }else{

            ?>

            <script type="text/javascript">
                swal("Error 100", "Hubo un error al registrarte", "error");
            </script>
    
    
            <?php
            
        }


}

/*    $sqlgrabar2 = "INSERT INTO $varnombreempresa(nombre_de_la_empresa) values ('$varnombreempresa')";
*/
?>