<?php

session_start();

if(isset($_SESSION['nombredeusuario'])){
    $usuarioingresado = $_SESSION['nombredeusuario'];
}else{
    header('location: inicio.php');

}

if(isset($_POST["cerrar_sesion"])){
    session_destroy();
    header("location: index.html");
}

include("conexion.php");
$varsucursal = "_sucursal";

$varregistrodesucursales = "SELECT * FROM $usuarioingresado".$varsucursal."";

$varusuariosregistrados = "SELECT * FROM $usuarioingresado";

?>

<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="Css/principal37.css">
        <link rel="icon" href="Recursos/Img/logo.png" type="img/png">

        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    </head>
    <body style="overflow-y:hidden">
    </body>
</html>

<?php


include("conexion.php");


$ejecutable=0;
if($ejecutable==0){





# Funciones predeterminadas | Inicio    
    function salir(){
        exit();
    }





$varmenu=8;
if ($varmenu==8){

    ?>

    <div class="seccion_menu_sistema">

        <div class="seccion_menu_sistema_superior">

            <div class="seccion_menu_sistema_superior_1">

        <?php

        $varusuariosregistrados2 = "SELECT * FROM $usuarioingresado WHERE nombre_de_la_empresa = '$usuarioingresado'";


        $resultado3 = mysqli_query($conn, $varusuariosregistrados2);
        while($row=mysqli_fetch_assoc($resultado3)){
        
        ?>
        
            <img class="imagen_usuario" src="data:img/jpg;base64,<?php echo base64_encode($row['imagen_usuario']);?>" />

        <?php
            }
        ?>

            </div>

            <div class="seccion_menu_sistema_superior_2">

                <form method="POST" class="form_opciones_2">
                    <input type="submit" class="opciones_menu_texto" value="<?php echo $usuarioingresado ?>" name="">
                </form>

            </div>

        </div>

        <div class="seccion_menu_sistema_intermedio">
        </div>



        <div class="seccion_menu_sistema_inferior">
            <div class="opciones_seccion_menu_sistema_inferior">
                <div class="opciones_seccion_menu_sistema_inferior_imagen">
                    <img src="Recursos/Img/usuario1.png" class="imagen_de_opciones_menu">
                </div>
                <div class="opciones_seccion_menu_sistema_inferior_texto">
                    <form method="POST" class="form_opciones">
                        <input type="submit" class="opciones_menu_texto" value="<?php echo $usuarioingresado ?>" name="">
                    </form>
                </div>
            </div>
            <div class="opciones_seccion_menu_sistema_inferior">
                <div class="opciones_seccion_menu_sistema_inferior_imagen">
                    <img src="Recursos/Img/configuraciones.png" class="imagen_de_opciones_menu">
                </div>
                <div class="opciones_seccion_menu_sistema_inferior_texto">
                    <form method="POST" class="form_opciones">
                        <input type="submit" class="opciones_menu_texto" value="Configuración" name="opcion_configuracion">
                    </form>
                </div>
            </div>
            <div class="opciones_seccion_menu_sistema_inferior">
                <div class="opciones_seccion_menu_sistema_inferior_imagen">
                    <img src="Recursos/Img/cerrarsesion.png" class="imagen_de_opciones_menu">
                </div>
                <div class="opciones_seccion_menu_sistema_inferior_texto">
                    <form method="POST" class="form_opciones">
                        <input type="submit" class="opciones_menu_texto" value="Cerrar sesión" name="cerrar_sesion">
                    </form>
                </div>
            </div>
        </div>

    </div>

<?php

}
# Funciones predeterminadas | Final    





if(isset($_POST["opcion_configuracion"])){
    $varsistema=11;

?>

    <div class="contenedor_sistema_2">

        <div class="circulo1_del_contenedor_inicio">

        </div>
        <div class="circulo2_del_contenedor_inicio">

        </div>
               
        <div class="contenedor_resultados_sistemas">

            <div class="seccion_titulo_resultados_sistema">
                <p class="titulo_sistema">Configuración</p>
            </div>
        




            <div class="seccion_principales_funciones_resultados_sistema">

                <div class="configuracion_seccion_principales_funciones_resultados_sistema_superior">
                    
                            <?php

                            $varusuariosregistrados = "SELECT * FROM $usuarioingresado WHERE nombre_de_la_empresa = '$usuarioingresado'";


                            $resultado3 = mysqli_query($conn, $varusuariosregistrados);
                            while($row=mysqli_fetch_assoc($resultado3)){
                            
                            ?>
                                <img class="imagen_portada_cargar" src="data:img/jpg;base64,<?php echo base64_encode($row['imagen_usuario']);?>" />

                            <?php
                                }
                            ?>

                </div>

                <div class="configuracion_seccion_principales_funciones_resultados_sistema_inferior">

                <form method='POST' enctype='multipart/form-data'>
                    <input name='imageninformacion' type='file' />

                    <input name='actualizarinformacion' type='submit' value='Actualizar' class='ajustes_info_texto'>
                </form>

                </div>

            </div>

            <div class="seccion_otras_funciones_resultados_sistema_2">
    
                <div class="apartado_divisaro_inferior">

                            <?php

                            $varusuariosregistrados = "SELECT * FROM $usuarioingresado WHERE nombre_de_la_empresa = '$usuarioingresado'";


                            $resultado3 = mysqli_query($conn, $varusuariosregistrados);
                            while($row=mysqli_fetch_assoc($resultado3)){
                            
                            ?>
                                <img class="imagen_portada_cargar" src="data:img/jpg;base64,<?php echo base64_encode($row['imagen_empresa']);?>" />

                            <?php
                                }
                            ?>
                            
                </div>

                <div class="apartado_divisaro_inferior">

                    <form method='POST' enctype='multipart/form-data'>

                        <input name='imagen_portada_db' type='file' />

                        <input name='actualizar_imagen_portada_db' type='submit' value='Actualizar' class='ajustes_info_texto'>

                    </form>
                
                </div>
                
            </div>
        
        </div>
        
    </div>  

<?php 

salir();
    }
    
?>





<!--------------------------------------------------------------------------
                  Sección de empleados | Inicio
---------------------------------------------------------------------------->
<?php
    if(isset($_POST["actualizarinformacion"]))
    {
        include("conexion.php");
    
        $varimagen = addslashes(file_get_contents($_FILES['imageninformacion']['tmp_name']));   
    
        $sqlgrabar = "UPDATE $usuarioingresado SET imagen_usuario = '$varimagen'";
    
    
        if (mysqli_query($conn, $sqlgrabar))
        {
            echo"<script> swal('Hola $nombre', 'Tus datos han sido actualizados', 'success');
            </script>";
        }else
        {
          echo"<script> swal('Lo sentimos :(', 'Ha ocurrido un error, intentalo más tarde', 'error');
          </script>";
        }
    
    }

    if(isset($_POST["actualizar_imagen_portada_db"]))
    {
        include("conexion.php");
    
        $varimagen2 = addslashes(file_get_contents($_FILES['imagen_portada_db']['tmp_name']));   
    
        $sqlgrabar = "UPDATE $usuarioingresado SET imagen_empresa = '$varimagen2'";
    
    
        if (mysqli_query($conn, $sqlgrabar))
        {
            echo"<script> swal('Hola', 'Tus datos han sido actualizados', 'success');
            </script>";
        }else
        {
          echo"<script> swal('Lo sentimos :(', 'Ha ocurrido un error, intentalo más tarde', 'error');
          </script>";
        }
    
    }

if(isset($_POST["opcion_empleados"])){
    $varsistema=11;

?>

    <div class="contenedor_sistema">

        <div class="circulo1_del_contenedor_inicio">

        </div>
        <div class="circulo2_del_contenedor_inicio">
            
        </div>
               
        <div class="contenedor_resultados_sistemas">

            <div class="seccion_titulo_resultados_sistema">
                <p class="titulo_sistema">Empleados</p>
            </div>
        




            <div class="seccion_principales_funciones_resultados_sistema">

                <div class="apartado_izquierdo_funciones_principales_sistemas">

                    <div class="empresa_funciones_principales"><!--tarjeta-->

                            <div class="empresa_funciones_principales_superior_registros">
                                <div class="empresa_funciones_principales_superior_registros_campo_1">
                                    <p class="texto_empresa_funciones_principales_superior_registros_campos">Nombre</p>
                                </div>
                                <div class="empresa_funciones_principales_superior_registros_campo_2">
                                    <p class="texto_empresa_funciones_principales_superior_registros_campos">Cargo</p>
                                </div>
                            </div>

                            <?php

                            $resultado3 = mysqli_query($conn, $varusuariosregistrados);
                            while($row=mysqli_fetch_assoc($resultado3)){
                            
                            ?>

                                <?php echo"<div class='texto_campo_registros_listado_1'>". $row["db_nombre_empleado"]."</div>"; ?>
                                <?php echo"<div class='texto_campo_registros_listado_2'>". $row["db_campo_cargo_empresa"]."</div>"; ?>

                            <?php
                                }
                            ?>

                        <div class="empresa_funciones_principales_texto">
                            <p class="texto_usuario_registrado">Lista de empleados</p>
                        </div>
        
                    </div><!--final de la tarjeta-->
        
                </div>
                




                <div class="apartado_derecho_funciones_principales_sistemas">
                    <div class="tarjetas_funciones_principales">
                        <div class="seccion_imagen_tarjetas_funciones_principales">
                            <img src="Recursos/Img/empleados.png" class="imagen_tarjetasfunciones_especiales">
                        </div>
                        <div class="seccion_texto_tarjetas_funciones_principales">
                            <p class="texto_tarjetas_funciones_especiales">Empleados</p>
                        </div>
                    </div>
                    <div class="tarjetas_funciones_principales">
                        <div class="seccion_imagen_tarjetas_funciones_principales">
                            <img src="Recursos/Img/agregarempleado.png" class="imagen_tarjetasfunciones_especiales">
                        </div>
                        <div class="seccion_texto_tarjetas_funciones_principales">
                            <form method="POST" class="form_opciones">
                                <input value="Nuevo empleado" type="submit" class="texto_tarjetas_funciones_especiales" name="input_submit_nuevoempleado">
                            </form>
                        </div>
                    </div>
                    <div class="tarjetas_funciones_principales">
                        <div class="seccion_imagen_tarjetas_funciones_principales">
                            <img src="Recursos/Img/empleados.png" class="imagen_tarjetasfunciones_especiales">
                        </div>
                        <div class="seccion_texto_tarjetas_funciones_principales">
                            <form class="form_opciones" method="POST">
                                <input type="submit" class="texto_tarjetas_funciones_especiales" value="Ajustar empleados" name="opcion_empleados">
                            </form>
                        </div>
                    </div>
                    <div class="tarjetas_funciones_principales">
                        <div class="seccion_imagen_tarjetas_funciones_principales">
                            <img src="Recursos/Img/eliminarempleado.png" class="imagen_tarjetasfunciones_especiales">
                        </div>
                        <div class="seccion_texto_tarjetas_funciones_principales">
                            <form method="POST" class="form_opciones">
                                <input value="Nuevo empleado" type="submit" class="texto_tarjetas_funciones_especiales" name="input_submit_eliminarempleado">
                            </form>
                        </div>
                    </div>
                    <div class="tarjetas_funciones_principales">
                        <div class="seccion_imagen_tarjetas_funciones_principales">
                            <img src="Recursos/Img/comunicados.png" class="imagen_tarjetasfunciones_especiales">
                        </div>
                        <div class="seccion_texto_tarjetas_funciones_principales">
                            <p class="texto_tarjetas_funciones_especiales">Modificar empleado</p>
                        </div>
                    </div>
                    <div class="tarjetas_funciones_principales">
                        <div class="seccion_imagen_tarjetas_funciones_principales">
                            <img src="Recursos/Img/reportes.png" class="imagen_tarjetasfunciones_especiales">
                        </div>
                        <div class="seccion_texto_tarjetas_funciones_principales">
                            <p class="texto_tarjetas_funciones_especiales">Ex-empleados</p>
                        </div>
                    </div>
                    
                </div>
            </div>
        
            <div class="seccion_otras_funciones_resultados_sistema">
        
                <div class="contenedor_de_opciones_y_funciones_universal">
                    <img src="Recursos/Img/basededatos.png" class="imagen_base_de_datos_universal">
                </div>
        
            </div>
            
        </div>
        
    </div>  

<?php 

    salir();

    }

?>





<?php

if(isset($_POST["input_submit_nuevoempleado"])){
    
    ?>
        
        <div class="contenedor_sistema">
        
            <div class="circulo1_del_contenedor_inicio"></div>
            <div class="circulo2_del_contenedor_inicio"></div>
            
            
            
            <div class="contenedor_resultados_sistemas">
                <div class="seccion_titulo_resultados_sistema">
                    <p class="titulo_sistema">Nuevo empleado</p>
                </div>
            
    
    
    
    
                <div class="seccion_principales_funciones_resultados_sistema"><!--Contenedor principal-->
    
                    <div class="apartado_izquierdo_funciones_principales_sistemas"><!--division del contenedor principal a la izquierda-->
    
                        <div class="empresa_funciones_principales"><!--tarjeta-->
    
                                <div class="empresa_funciones_principales_superior_registros"><!--titulo de la tarjeta, parte superior azul-->
                                    <div class="empresa_funciones_principales_superior_registros_campo_1">
                                        <p class="texto_empresa_funciones_principales_superior_registros_campos">Nombre</p>
                                    </div>
                                    <div class="empresa_funciones_principales_superior_registros_campo_2">
                                        <p class="texto_empresa_funciones_principales_superior_registros_campos">Cargo</p>
                                    </div>
                                </div><!--final del titulo de la tarjeta, parte superior azul-->
    
                                <?php

                                $resultado3 = mysqli_query($conn, $varusuariosregistrados);
                                while($row=mysqli_fetch_assoc($resultado3)){
                            
                                ?>

                                    <?php echo"<div class='texto_campo_registros_listado_1'>". $row["db_nombre_empleado"]."</div>"; ?>
                                    <?php echo"<div class='texto_campo_registros_listado_2'>". $row["db_campo_cargo_empresa"]."</div>"; ?>

                                <?php
                                    }
                                ?>

    
                                <div class="empresa_funciones_principales_texto">
                                    <p class="texto_usuario_registrado">Lista de sucursales</p>
                                </div>
    
                        </div><!--final de la tarjeta-->
            
                    </div><!--final de la division del contenedor principal a la izquierda-->
    
    
    
    
    
                    <div class="apartado_derecho_funciones_principales_sistemas">
                        <div class="tarjetas_funciones_principales">
                            <div class="seccion_imagen_tarjetas_funciones_principales">
                                <img src="Recursos/Img/empleados.png" class="imagen_tarjetasfunciones_especiales">
                            </div>
                            <div class="seccion_texto_tarjetas_funciones_principales">
                                <p class="texto_tarjetas_funciones_especiales">Empleados</p>
                            </div>
                        </div>
                        <div class="tarjetas_funciones_principales ejecutado_submit_campo_principal">
                            <div class="seccion_imagen_tarjetas_funciones_principales">
                                <img src="Recursos/Img/agregarempleado.png" class="imagen_tarjetasfunciones_especiales">
                            </div>
                            <div class="seccion_texto_tarjetas_funciones_principales">
                                <form method="POST" class="form_opciones">
                                    <input value="Nuevo empleado" type="submit" class="texto_tarjetas_funciones_especiales ejecutado_submit_texto" name="input_submit_nuevoempleado">
                                </form>
                            </div>
                        </div>
                        <div class="tarjetas_funciones_principales">
                            <div class="seccion_imagen_tarjetas_funciones_principales">
                                <img src="Recursos/Img/empleados.png" class="imagen_tarjetasfunciones_especiales">
                            </div>
                            <div class="seccion_texto_tarjetas_funciones_principales">
                                <form class="form_opciones" method="POST">
                                    <input type="submit" class="texto_tarjetas_funciones_especiales" value="Ajustar empleados" name="opcion_empleados">
                                </form>
                            </div>
                        </div>
                        <div class="tarjetas_funciones_principales">
                            <div class="seccion_imagen_tarjetas_funciones_principales">
                                <img src="Recursos/Img/eliminarempleado.png" class="imagen_tarjetasfunciones_especiales">
                            </div>
                            <div class="seccion_texto_tarjetas_funciones_principales">
                                <form method="POST" class="form_opciones">
                                    <input value="Eliminar empleado" type="submit" class="texto_tarjetas_funciones_especiales" name="input_submit_eliminarempleado">
                                </form>
                            </div>
                        </div>
                        <div class="tarjetas_funciones_principales">
                            <div class="seccion_imagen_tarjetas_funciones_principales">
                                <img src="Recursos/Img/comunicados.png" class="imagen_tarjetasfunciones_especiales">
                            </div>
                            <div class="seccion_texto_tarjetas_funciones_principales">
                                <p class="texto_tarjetas_funciones_especiales">Modificar empleado</p>
                            </div>
                        </div>
                        <div class="tarjetas_funciones_principales">
                            <div class="seccion_imagen_tarjetas_funciones_principales">
                                <img src="Recursos/Img/reportes.png" class="imagen_tarjetasfunciones_especiales">
                            </div>
                            <div class="seccion_texto_tarjetas_funciones_principales">
                                <p class="texto_tarjetas_funciones_especiales">Ex-empleados</p>
                            </div>
                        </div>
                        
                    </div>
                </div>
            
                <div class="seccion_otras_funciones_resultados_sistema">
            
                    <div class="contenedor_de_opciones_y_funciones_universal">
                        <form method="POST" class="form_opciones_2">
    
                            <div class="contenedor_input_text_funciones_universales">
                                <input type="text" placeholder="Nombre" class="input_texto_funciones_extras ajuste_campos_1" name="campo_nombre_empresa" required>
                                <input type="text" placeholder="Puesto" class="input_texto_funciones_extras ajuste_campos_1" name="campo_cargo_dentro_de_la_empresa" required>
                                <input type="text" placeholder="Jefe" class="input_texto_funciones_extras ajuste_campos_1" name="campo_jefe_empresa" required>
                                <select class="input_texto_funciones_extras ajuste_campos_1" name="campo_cargoenelsistema">
                                    <option value="Administrador">Administrador</option>
                                    <option value="General">General</option>
                                </select>
    
    
    
    
    
                                <select class="input_texto_funciones_extras ajuste_campos_1" name="campo_sucursal_empresa">
                                    
                                    <?php
                                    include("conexion.php");
    
                                    $resultado = mysqli_query($conn, $varregistrodesucursales);
                                    while($row=mysqli_fetch_array($resultado))
                                    {
                                
                                        $nombre1 = $row["db_nombre_sucursal"];
                                        $nombre2 = $row["db_ubicacion_sucursal"];
                                
                                    ?>
    
                                    <option value="<?php echo $nombre1; ?>"><?php echo $nombre1; ?></option>
    
                                    <?php
                                        }
                                    ?>
    
                                </select>
    
    
    
    
    
                                <input type="text" placeholder="Sueldo" class="input_texto_funciones_extras ajuste_campos_1" name="campo_sueldo_empresa" required>
                                <input type="text" placeholder="Días de trabajo" class="input_texto_funciones_extras ajuste_campos_1" name="campo_dias_empresa" required>
                                <input type="text" placeholder="Horario de trabajo" class="input_texto_funciones_extras ajuste_campos_1" name="campo_horario_empresa" required>
                                <input type="password" placeholder="Contraseña" class="input_texto_funciones_extras" name="campo_contrasena_empresa1" required>
                                <input type="password" placeholder="Confirmar contraseña" class="input_texto_funciones_extras" name="campo_contrasena_empresa2" required>
                            </div>
    
                            <div class="contenedor_input_sumit_funciones_universales">
                                <input type="submit" value="Registrar" class="input__submit_funciones_extras" name="campo_agregar_empleado_bd">
                            </div>
                            
                        </form>
                    </div>
            
                </div>
    
            </div>
            
        </div>
    
<?php 

    salir();

    }

?>





<?php

if(isset($_POST["input_submit_eliminarempleado"])){
    
    ?>
        
        <div class="contenedor_sistema"><!--Contenedor principal-->
    
            <div class="circulo1_del_contenedor_inicio"></div>
            <div class="circulo2_del_contenedor_inicio"></div>
            
            
            
            <div class="contenedor_resultados_sistemas"><!--contenedor resultados del sistema-->
    
                <div class="seccion_titulo_resultados_sistema">
                    <p class="titulo_sistema">Eliminar empleado</p>
                </div>
    
                
    
                
    
                <div class="seccion_principales_funciones_resultados_sistema"><!--contenedor principal-->
    
                    <div class="apartado_izquierdo_funciones_principales_sistemas"><!--division del contenedor principal a la izquierda-->
    
                        <div class="empresa_funciones_principales"><!--tarjeta-->
    
                                <div class="empresa_funciones_principales_superior_registros"><!--titulo de la tarjeta, parte superior azul-->
                                    <div class="empresa_funciones_principales_superior_registros_campo_1">
                                        <p class="texto_empresa_funciones_principales_superior_registros_campos">Nombre</p>
                                    </div>
                                    <div class="empresa_funciones_principales_superior_registros_campo_2">
                                        <p class="texto_empresa_funciones_principales_superior_registros_campos">Cargo</p>
                                    </div>
                                </div><!--final del titulo de la tarjeta, parte superior azul-->
    
                                <?php

                                $resultado3 = mysqli_query($conn, $varusuariosregistrados);
                                while($row=mysqli_fetch_assoc($resultado3)){
                            
                                ?>

                                    <?php echo"<div class='texto_campo_registros_listado_1'>". $row["db_nombre_empleado"]."</div>"; ?>
                                    <?php echo"<div class='texto_campo_registros_listado_2'>". $row["db_campo_cargo_empresa"]."</div>"; ?>

                                <?php
                                    }
                                ?>
    
                                <div class="empresa_funciones_principales_texto">
                                    <p class="texto_usuario_registrado">Lista de empleados eliminados</p>
                                </div>
    
                        </div><!--final de la tarjeta-->
            
                    </div><!--final de la division del contenedor principal a la izquierda-->
    
    
    
    
    
                    <div class="apartado_derecho_funciones_principales_sistemas">
                        <div class="tarjetas_funciones_principales">
                            <div class="seccion_imagen_tarjetas_funciones_principales">
                                <img src="Recursos/Img/empleados.png" class="imagen_tarjetasfunciones_especiales">
                            </div>
                            <div class="seccion_texto_tarjetas_funciones_principales">
                                <p class="texto_tarjetas_funciones_especiales">Empleados</p>
                            </div>
                        </div>
                        <div class="tarjetas_funciones_principales">
                            <div class="seccion_imagen_tarjetas_funciones_principales">
                                <img src="Recursos/Img/agregarempleado.png" class="imagen_tarjetasfunciones_especiales">
                            </div>
                            <div class="seccion_texto_tarjetas_funciones_principales">
                                <form method="POST" class="form_opciones">
                                    <input value="Nuevo empleado" type="submit" class="texto_tarjetas_funciones_especiales" name="input_submit_nuevoempleado">
                                </form>
                            </div>
                        </div>
                        <div class="tarjetas_funciones_principales">
                            <div class="seccion_imagen_tarjetas_funciones_principales">
                                <img src="Recursos/Img/empleados.png" class="imagen_tarjetasfunciones_especiales">
                            </div>
                            <div class="seccion_texto_tarjetas_funciones_principales">
                                <form class="form_opciones" method="POST">
                                    <input type="submit" class="texto_tarjetas_funciones_especiales" value="Ajustar empleado" name="opcion_empleados">
                                </form>
                            </div>
                        </div>
                        <div class="tarjetas_funciones_principales ejecutado_submit_campo_principal">
                            <div class="seccion_imagen_tarjetas_funciones_principales">
                                <img src="Recursos/Img/eliminarempleado.png" class="imagen_tarjetasfunciones_especiales">
                            </div>
                            <div class="seccion_texto_tarjetas_funciones_principales">
                                <form method="POST" class="form_opciones">
                                    <input value="Eliminar empleado" type="submit" class="texto_tarjetas_funciones_especiales ejecutado_submit_texto" name="input_submit_eliminarempleado">
                                </form>
                            </div>
                        </div>
    
                        <div class="tarjetas_funciones_principales">
                            <div class="seccion_imagen_tarjetas_funciones_principales">
                                <img src="Recursos/Img/comunicados.png" class="imagen_tarjetasfunciones_especiales">
                            </div>
                            <div class="seccion_texto_tarjetas_funciones_principales">
                                <p class="texto_tarjetas_funciones_especiales">Notas de sucursales</p>
                            </div>
                        </div>
    
                        <div class="tarjetas_funciones_principales">
                            <div class="seccion_imagen_tarjetas_funciones_principales">
                                <img src="Recursos/Img/reportes.png" class="imagen_tarjetasfunciones_especiales">
                            </div>
                            <div class="seccion_texto_tarjetas_funciones_principales">
                                <p class="texto_tarjetas_funciones_especiales">Ex-sucursal</p>
                            </div>
                        </div>
                        
                    </div><!--final de la division del contenedor principal a la izquierda-->
    
                </div><!--final del contenedor principal-->
            
                <div class="seccion_otras_funciones_resultados_sistema">
            
                    <div class="contenedor_de_opciones_y_funciones_universal">
                        <form method="POST" class="form_opciones_2">
    
                            <div class="contenedor_input_text_funciones_universales">
                                <input type="text" placeholder="Nombre del empleado" class="input_texto_funciones_extras ajuste_campos_1" name="campo_nombre_empleado" required>
                                <input type="password" placeholder="Contraseña del empleado" class="input_texto_funciones_extras ajuste_campos_1" name="campo_contrasena_empleado" required>
                            </div>
    
                            <div class="contenedor_input_sumit_funciones_universales">
                                <input type="submit" value="Eliminar" class="input__submit_funciones_extras" name="campo_eliminar_empleado_bd">
                            </div>
                            
                        </form>
                    </div>
            
                </div>
    
            </div><!--final del contenedor resultados del sistema-->
            
        </div><!--final del contenedor principal-->
    
<?php 

    salir();
            
    }

?>
<!--------------------------------------------------------------------------
                  Sección de empleados | Final
---------------------------------------------------------------------------->    





<!--------------------------------------------------------------------------
                  Sección de sucursales | Inicio
---------------------------------------------------------------------------->
<?php

if(isset($_POST["opcion_sucursales"])){
?>

    <div class="contenedor_sistema">

        <div class="circulo1_del_contenedor_inicio">

        </div>
        <div class="circulo2_del_contenedor_inicio">

        </div>
               
        <div class="contenedor_resultados_sistemas">

            <div class="seccion_titulo_resultados_sistema">
                <p class="titulo_sistema">Sucursales</p>
            </div>
        
            <div class="seccion_principales_funciones_resultados_sistema"><!--contenedor principal-->

                <div class="apartado_izquierdo_funciones_principales_sistemas"><!--division del contenedor principal a la izquierda-->

                    <div class="empresa_funciones_principales"><!--tarjeta-->

                            <div class="empresa_funciones_principales_superior_registros"><!--titulo de la tarjeta, parte superior azul-->
                                <div class="empresa_funciones_principales_superior_registros_campo_1">
                                    <p class="texto_empresa_funciones_principales_superior_registros_campos">Nombre</p>
                                </div>
                                <div class="empresa_funciones_principales_superior_registros_campo_2">
                                    <p class="texto_empresa_funciones_principales_superior_registros_campos">Cargo</p>
                                </div>
                            </div><!--final del titulo de la tarjeta, parte superior azul-->

                            <?php

                            $resultado3 = mysqli_query($conn, $varregistrodesucursales);
                            while($row=mysqli_fetch_assoc($resultado3)){
                            
                            ?>

                                <?php echo"<div class='texto_campo_registros_listado_1'>". $row["db_nombre_sucursal"]."</div>"; ?>
                                <?php echo"<div class='texto_campo_registros_listado_2'>". $row["db_ubicacion_sucursal"]."</div>"; ?>

                            <?php
                                }
                            ?>

                            <div class="empresa_funciones_principales_texto">
                                <p class="texto_usuario_registrado">Lista de sucursales</p>
                            </div>

                    </div><!--final de la tarjeta-->
        
                </div><!--final de la division del contenedor principal a la izquierda-->

                <div class="apartado_derecho_funciones_principales_sistemas">
                    <div class="tarjetas_funciones_principales">
                        <div class="seccion_imagen_tarjetas_funciones_principales">
                            <img src="Recursos/Img/sucursal.png" class="imagen_tarjetasfunciones_especiales">
                        </div>
                        <div class="seccion_texto_tarjetas_funciones_principales">
                            <p class="texto_tarjetas_funciones_especiales">Sucursales</p>
                        </div>
                    </div>
                    <div class="tarjetas_funciones_principales">
                        <div class="seccion_imagen_tarjetas_funciones_principales">
                            <img src="Recursos/Img/agregarsucursal.png" class="imagen_tarjetasfunciones_especiales">
                        </div>
                        <div class="seccion_texto_tarjetas_funciones_principales">
                            <form method="POST" class="form_opciones">
                                <input value="Nueva sucursal" type="submit" class="texto_tarjetas_funciones_especiales" name="input_submit_nuevasucursal">
                            </form>
                        </div>
                    </div>
                    <div class="tarjetas_funciones_principales">
                        <div class="seccion_imagen_tarjetas_funciones_principales">
                            <img src="Recursos/Img/modificarsucursal.png" class="imagen_tarjetasfunciones_especiales">
                        </div>
                        <div class="seccion_texto_tarjetas_funciones_principales">
                            <form class="form_opciones" method="POST">
                                <input type="submit" class="texto_tarjetas_funciones_especiales" value="Ajuste de sucursales" name="opcion_empleados">
                            </form>
                        </div>
                    </div>
                    <div class="tarjetas_funciones_principales">
                        <div class="seccion_imagen_tarjetas_funciones_principales">
                            <img src="Recursos/Img/eliminarsucursal.png" class="imagen_tarjetasfunciones_especiales">
                        </div>
                        <div class="seccion_texto_tarjetas_funciones_principales">
                            <p class="texto_tarjetas_funciones_especiales">Eliminar sucursal</p>
                        </div>
                    </div>
                    <div class="tarjetas_funciones_principales">
                        <div class="seccion_imagen_tarjetas_funciones_principales">
                            <img src="Recursos/Img/comunicados.png" class="imagen_tarjetasfunciones_especiales">
                        </div>
                        <div class="seccion_texto_tarjetas_funciones_principales">
                            <p class="texto_tarjetas_funciones_especiales">Modificar sucursal</p>
                        </div>
                    </div>
                    <div class="tarjetas_funciones_principales">
                        <div class="seccion_imagen_tarjetas_funciones_principales">
                            <img src="Recursos/Img/reportes.png" class="imagen_tarjetasfunciones_especiales">
                        </div>
                        <div class="seccion_texto_tarjetas_funciones_principales">
                            <p class="texto_tarjetas_funciones_especiales">Ex-sucursales</p>
                        </div>
                    </div>
                    
                </div>

            </div><!--final del contenedor principal-->
        
            <div class="seccion_otras_funciones_resultados_sistema">
        
                <div class="contenedor_de_opciones_y_funciones_universal">
                    <img src="Recursos/Img/basededatos.png" class="imagen_base_de_datos_universal">
                </div>
        
            </div>
        </div>
        
    </div>

<?php 

    salir();

    }

?>






<?php

if(isset($_POST["input_submit_nuevasucursal"])){
?>


    <div class="contenedor_sistema"><!--Contenedor principal-->

        <div class="circulo1_del_contenedor_inicio"></div>
        <div class="circulo2_del_contenedor_inicio"></div>
        
        
        
        <div class="contenedor_resultados_sistemas"><!--contenedor resultados del sistema-->

            <div class="seccion_titulo_resultados_sistema">
                <p class="titulo_sistema">Sucursales</p>
            </div>

            

            

            <div class="seccion_principales_funciones_resultados_sistema"><!--contenedor principal-->

                <div class="apartado_izquierdo_funciones_principales_sistemas"><!--division del contenedor principal a la izquierda-->

                    <div class="empresa_funciones_principales"><!--tarjeta-->

                            <div class="empresa_funciones_principales_superior_registros"><!--titulo de la tarjeta, parte superior azul-->
                                <div class="empresa_funciones_principales_superior_registros_campo_1">
                                    <p class="texto_empresa_funciones_principales_superior_registros_campos">Nombre</p>
                                </div>
                                <div class="empresa_funciones_principales_superior_registros_campo_2">
                                    <p class="texto_empresa_funciones_principales_superior_registros_campos">Cargo</p>
                                </div>
                            </div><!--final del titulo de la tarjeta, parte superior azul-->

                            <?php

                            $resultado3 = mysqli_query($conn, $varregistrodesucursales);
                            while($row=mysqli_fetch_assoc($resultado3)){
                            
                            ?>

                                <?php echo"<div class='texto_campo_registros_listado_1'>". $row["db_nombre_sucursal"]."</div>"; ?>
                                <?php echo"<div class='texto_campo_registros_listado_2'>". $row["db_ubicacion_sucursal"]."</div>"; ?>

                            <?php
                                }
                            ?>

                            <div class="empresa_funciones_principales_texto">
                                <p class="texto_usuario_registrado">Lista de sucursales</p>
                            </div>

                    </div><!--final de la tarjeta-->
        
                </div><!--final de la division del contenedor principal a la izquierda-->





                <div class="apartado_derecho_funciones_principales_sistemas">
                    <div class="tarjetas_funciones_principales">
                        <div class="seccion_imagen_tarjetas_funciones_principales">
                            <img src="Recursos/Img/sucursal.png" class="imagen_tarjetasfunciones_especiales">
                        </div>
                        <div class="seccion_texto_tarjetas_funciones_principales">
                            <p class="texto_tarjetas_funciones_especiales">Sucursales</p>
                        </div>
                    </div>
                    <div class="tarjetas_funciones_principales ejecutado_submit_campo_principal">
                        <div class="seccion_imagen_tarjetas_funciones_principales">
                            <img src="Recursos/Img/agregarsucursal.png" class="imagen_tarjetasfunciones_especiales">
                        </div>
                        <div class="seccion_texto_tarjetas_funciones_principales">
                            <form method="POST" class="form_opciones">
                                <input value="Nueva sucursal" type="submit" class="texto_tarjetas_funciones_especiales ejecutado_submit_texto" name="input_submit_nuevasucursal">
                            </form>
                        </div>
                    </div>
                    <div class="tarjetas_funciones_principales">
                        <div class="seccion_imagen_tarjetas_funciones_principales">
                            <img src="Recursos/Img/modificarsucursal.png" class="imagen_tarjetasfunciones_especiales">
                        </div>
                        <div class="seccion_texto_tarjetas_funciones_principales">
                            <form class="form_opciones" method="POST">
                                <input type="submit" class="texto_tarjetas_funciones_especiales" value="Ajustar sucursal" name="opcion_empleados">
                            </form>
                        </div>
                    </div>
                    <div class="tarjetas_funciones_principales">
                        <div class="seccion_imagen_tarjetas_funciones_principales">
                            <img src="Recursos/Img/eliminarsucursal.png" class="imagen_tarjetasfunciones_especiales">
                        </div>
                        <div class="seccion_texto_tarjetas_funciones_principales">
                            <p class="texto_tarjetas_funciones_especiales">Eliminar sucursal</p>
                        </div>
                    </div>

                    <div class="tarjetas_funciones_principales">
                        <div class="seccion_imagen_tarjetas_funciones_principales">
                            <img src="Recursos/Img/comunicados.png" class="imagen_tarjetasfunciones_especiales">
                        </div>
                        <div class="seccion_texto_tarjetas_funciones_principales">
                            <p class="texto_tarjetas_funciones_especiales">Notas de sucursales</p>
                        </div>
                    </div>

                    <div class="tarjetas_funciones_principales">
                        <div class="seccion_imagen_tarjetas_funciones_principales">
                            <img src="Recursos/Img/reportes.png" class="imagen_tarjetasfunciones_especiales">
                        </div>
                        <div class="seccion_texto_tarjetas_funciones_principales">
                            <p class="texto_tarjetas_funciones_especiales">Ex-sucursal</p>
                        </div>
                    </div>
                    
                </div><!--final de la division del contenedor principal a la izquierda-->

            </div><!--final del contenedor principal-->
        
            <div class="seccion_otras_funciones_resultados_sistema">
        
                <div class="contenedor_de_opciones_y_funciones_universal">
                    <form method="POST" class="form_opciones_2">

                        <div class="contenedor_input_text_funciones_universales">
                            <input type="text" placeholder="Nombre de la sucursal" class="input_texto_funciones_extras ajuste_campos_1" name="campo_nombre_sucursal" required>
                            <input type="text" placeholder="Dirección de la sucursal" class="input_texto_funciones_extras ajuste_campos_1" name="campo_ubicacion_sucursal" required>
                        </div>

                        <div class="contenedor_input_sumit_funciones_universales">
                            <input type="submit" value="Registrar" class="input__submit_funciones_extras" name="campo_agregar_sucursal_bd">
                        </div>
                        
                    </form>
                </div>
        
            </div>

        </div><!--final del contenedor resultados del sistema-->
        
    </div><!--final del contenedor principal-->

<?php

    salir();

    }

?>
<!--------------------------------------------------------------------------
                  Sección de sucursales | Final
---------------------------------------------------------------------------->




    
<?php

    if(isset($_POST["campo_agregar_sucursal_bd"])){

        include("conexion.php");
    

        $varnombresucursal= $_POST["campo_nombre_sucursal"];
        $varubicacionsucursal = $_POST["campo_ubicacion_sucursal"];
        $varsucursal = "_sucursal";


        $sqlgrabar = "INSERT INTO $usuarioingresado".$varsucursal."(db_nombre_sucursal,db_ubicacion_sucursal) values ('$varnombresucursal','$varubicacionsucursal')";

            if(mysqli_query($conn,$sqlgrabar)){
                ?>

                <script type="text/javascript">
                    swal("Sucursal registrada", "La sucursal <?php echo $varnombresucursal ?> quedó registrada", "success");
                </script>
        
        
                <?php
            }else{
                echo"Error: ".$sql."<br>".mysql_error($conn);
            }
        
    }




    #Inicio | Eliminar empleado
    if(isset($_POST["campo_eliminar_empleado_bd"])){

        include("conexion.php");
    

        $varnombredelempleadoaeliminar= $_POST["campo_nombre_empleado"];
        $varcontrasenadelempleadoaeliminar = $_POST["campo_contrasena_empleado"];

        
        $sqleliminar = "DELETE FROM $usuarioingresado WHERE db_nombre_empleado='$varnombredelempleadoaeliminar' AND db_contrasena_empreado='$varcontrasenadelempleadoaeliminar'";

            if(mysqli_query($conn,$sqleliminar)){
                header('Location: sistema.php');
            }else{
                echo"Error: ".$sql."<br>".mysql_error($conn);
            }
        
    }
    #Final | Eliminar empleado





    if(isset($_POST["campo_agregar_empleado_bd"])){

        include("conexion.php");
    

        $varnombreempresa = $_POST["campo_nombre_empresa"];
        $varcargoempresa = $_POST["campo_cargo_dentro_de_la_empresa"];
        $varjefemepresa = $_POST["campo_jefe_empresa"];
        $varsucursalempresa = $_POST["campo_sucursal_empresa"];
        $varsueldoempresa = $_POST["campo_sueldo_empresa"];
        $vardiasempresa = $_POST["campo_dias_empresa"];
        $varhorarioempresa = $_POST["campo_horario_empresa"];
        $varcontrasena1 = $_POST["campo_contrasena_empresa1"];
        $varcontrasena2 = $_POST["campo_contrasena_empresa2"];
        $cargoenelsistema = $_POST["campo_cargoenelsistema"];

        $varcontrasena1_fuerte = password_hash($varcontrasena1, PASSWORD_DEFAULT);

        if($varcontrasena1 == $varcontrasena2){

            $sqlgrabar = "INSERT INTO $usuarioingresado(cargo_de_la_persona,db_nombre_empleado,db_campo_cargo_empresa,db_campo_jefe_empresa,db_campo_sucursal_empresa,db_campo_sueldo_empresa,db_campo_dias_empresa,db_campo_horario_empresa,db_contrasena_empreado) values ('$cargoenelsistema','$varnombreempresa','$varcargoempresa','$varjefemepresa','$varsucursalempresa','$varsueldoempresa','$vardiasempresa','$varhorarioempresa','$varcontrasena1_fuerte')";
      
            if(mysqli_query($conn,$sqlgrabar)){
                ?>

                <script type="text/javascript">
                    swal("Registrado", "El empleado ha sido registrado exitosamente", "success");
                    header("Location: inicio.php");
                </script>
    
                <?php

            }else{
                echo"Error: ".$sql."<br>".mysql_error($conn);
            }  

        }else{
            echo"<script> alert('Las contraseñas no coinciden'); window.location='sistema.php'</script>";
        }            
        
    }
?>

<?php


$varsistema=7;
if($varsistema==7){
?>

<div class="contenedor_sistema">

        <div class="circulo1_del_contenedor_inicio">
        </div>

        <div class="circulo2_del_contenedor_inicio">
        </div>

        <div class="seccion_titulo_resultados_sistema">
            <p class="titulo_sistema">Inicio</p>
        </div>



        <div class="seccion_principales_funciones_resultados_sistema">

            <div class="apartado_izquierdo_funciones_principales_sistemas">

                <div class="empresa_funciones_principales">

                    <div class="empresa_funciones_principales_imagen">

                    <?php

                    $varusuariosregistrados = "SELECT * FROM $usuarioingresado WHERE nombre_de_la_empresa = '$usuarioingresado'";


                    $resultado3 = mysqli_query($conn, $varusuariosregistrados);
                    while($row=mysqli_fetch_assoc($resultado3)){
                    
                    ?>

                        <img class="imagen_portada_miniatura" src="data:img/jpg;base64,<?php echo base64_encode($row['imagen_empresa']);?>" />

                    <?php
                        }
                    ?>

                    </div>

                    <div class="empresa_funciones_principales_texto">
                        <p class="texto_usuario_registrado"><?php echo $usuarioingresado ?></p>
                    </div>

                </div>

            </div>
        



            <div class="apartado_derecho_funciones_principales_sistemas">

                <div class="tarjetas_funciones_principales">

                    <div class="seccion_imagen_tarjetas_funciones_principales">
                        <img src="Recursos/Img/sucursal.png" class="imagen_tarjetasfunciones_especiales">
                    </div>

                    <div class="seccion_texto_tarjetas_funciones_principales">
                        <form class="form_opciones" method="POST">
                            <input type="submit" class="texto_tarjetas_funciones_especiales" value="Sucursales" name="opcion_sucursales">
                        </form>
                    </div>

                </div>

                <div class="tarjetas_funciones_principales">

                    <div class="seccion_imagen_tarjetas_funciones_principales">
                        <img src="Recursos/Img/negocios.png" class="imagen_tarjetasfunciones_especiales">
                    </div>
                    <div class="seccion_texto_tarjetas_funciones_principales">
                        <p class="texto_tarjetas_funciones_especiales">Negocios</p>
                    </div>

                </div>

                <div class="tarjetas_funciones_principales">

                    <div class="seccion_imagen_tarjetas_funciones_principales">
                        <img src="Recursos/Img/empleados.png" class="imagen_tarjetasfunciones_especiales">
                    </div>

                    <div class="seccion_texto_tarjetas_funciones_principales">
                        <form class="form_opciones" method="POST">
                            <input type="submit" class="texto_tarjetas_funciones_especiales" value="Empleados" name="opcion_empleados">
                        </form>
                    </div>

                </div>

                <div class="tarjetas_funciones_principales">
                    <div class="seccion_imagen_tarjetas_funciones_principales">
                        <img src="Recursos/Img/inventario.png" class="imagen_tarjetasfunciones_especiales">
                    </div>
                    <div class="seccion_texto_tarjetas_funciones_principales">
                        <p class="texto_tarjetas_funciones_especiales">Inventario</p>
                    </div>
                </div>
                <div class="tarjetas_funciones_principales">
                    <div class="seccion_imagen_tarjetas_funciones_principales">
                        <img src="Recursos/Img/comunicados.png" class="imagen_tarjetasfunciones_especiales">
                    </div>
                    <div class="seccion_texto_tarjetas_funciones_principales">
                        <p class="texto_tarjetas_funciones_especiales">Comunicados</p>
                    </div>
                </div>
                <div class="tarjetas_funciones_principales">
                    <div class="seccion_imagen_tarjetas_funciones_principales">
                        <img src="Recursos/Img/reportes.png" class="imagen_tarjetasfunciones_especiales">
                    </div>
                    <div class="seccion_texto_tarjetas_funciones_principales">
                        <p class="texto_tarjetas_funciones_especiales">Reportes</p>
                    </div>
                </div>
            
            </div>

        </div>



            <div class="seccion_otras_funciones_resultados_sistema">

                <div class="tarjetas_otras_funciones_resultados_sistemas">
                    <div class="seccion_imagen_tarjeta_funciones_resultados_sistemas">
                        <img src="Recursos/Img/clientes.png" class="imagen_tarjeta_funciones_resultados_sistemas">
                    </div>
                    <div class="seccion_texto_cantidad_tarjeta_funciones_resultados_sistemas">
                        <p class="texto_cantidad_tarjeta_funciones_resultados_sistemas">Registrados</p>
                    </div>
                    <div class="seccion_texto_nombre_tarjeta_funciones_resultados_sistemas">
                        <p class="texto_nombre_tarjeta_funciones_resultados_sistemas">Clientes</p>
                    </div>
                </div>

                <div class="tarjetas_otras_funciones_resultados_sistemas">
                    <div class="seccion_imagen_tarjeta_funciones_resultados_sistemas">
                        <img src="Recursos/Img/etiqueta.png" class="imagen_tarjeta_funciones_resultados_sistemas">
                    </div>
                    <div class="seccion_texto_cantidad_tarjeta_funciones_resultados_sistemas">
                        <p class="texto_cantidad_tarjeta_funciones_resultados_sistemas">Etiquetas</p>
                    </div>
                    <div class="seccion_texto_nombre_tarjeta_funciones_resultados_sistemas">
                        <p class="texto_nombre_tarjeta_funciones_resultados_sistemas">Categorías</p>
                    </div>
                </div>

                <div class="tarjetas_otras_funciones_resultados_sistemas">
                    <div class="seccion_imagen_tarjeta_funciones_resultados_sistemas">
                        <img src="Recursos/Img/calendario.png" class="imagen_tarjeta_funciones_resultados_sistemas">
                    </div>
                    <div class="seccion_texto_cantidad_tarjeta_funciones_resultados_sistemas">
                        <p class="texto_cantidad_tarjeta_funciones_resultados_sistemas">Actividades</p>
                    </div>
                    <div class="seccion_texto_nombre_tarjeta_funciones_resultados_sistemas">
                        <p class="texto_nombre_tarjeta_funciones_resultados_sistemas">Calendario</p>
                    </div>
                </div>

                <div class="tarjetas_otras_funciones_resultados_sistemas">
                    <div class="seccion_imagen_tarjeta_funciones_resultados_sistemas">
                        <img src="Recursos/Img/convenio.png" class="imagen_tarjeta_funciones_resultados_sistemas">
                    </div>
                    <div class="seccion_texto_cantidad_tarjeta_funciones_resultados_sistemas">
                        <p class="texto_cantidad_tarjeta_funciones_resultados_sistemas">Vigentes</p>
                    </div>
                    <div class="seccion_texto_nombre_tarjeta_funciones_resultados_sistemas">
                        <p class="texto_nombre_tarjeta_funciones_resultados_sistemas">Convenios</p>
                    </div>
                </div>

            </div>


    </div>
    
<?php

}





} /* Final del IF principal*/

?>